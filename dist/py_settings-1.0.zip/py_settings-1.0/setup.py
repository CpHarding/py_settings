from distutils.core import setup

setup(name='py_settings',
      version='1.0',
      description='Python Settings file',
      author='Chris Haridng',
      author_email='Cph.github@gmail.com',
      url='https://github.com/CpHarding/py_settings',
      py_modules=['py_settings'],
     )